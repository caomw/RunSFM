for i in {0..9999}
do
    file=`printf "option-%04d" $i`

    if [ -f pmvs/$file ] 
    then
        ../RunSFM/cmvs/program/main/pmvs2 pmvs/ $file
    else
        break
    fi
done
